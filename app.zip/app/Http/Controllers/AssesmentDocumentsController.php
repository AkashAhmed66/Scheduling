<?php

namespace App\Http\Controllers;

use App\Models\AssesmentDocuments;
use App\Http\Requests\StoreAssesmentDocumentsRequest;
use App\Http\Requests\UpdateAssesmentDocumentsRequest;

class AssesmentDocumentsController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreAssesmentDocumentsRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(AssesmentDocuments $assesmentDocuments)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(AssesmentDocuments $assesmentDocuments)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateAssesmentDocumentsRequest $request, AssesmentDocuments $assesmentDocuments)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(AssesmentDocuments $assesmentDocuments)
    {
        //
    }
}
