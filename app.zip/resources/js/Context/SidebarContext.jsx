import React, { createContext } from 'react';

const SidebarContext = createContext();

export default SidebarContext;

