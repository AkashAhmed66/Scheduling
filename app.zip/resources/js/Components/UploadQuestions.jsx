import React from 'react'

export default function UploadQuestions() {
  return (
    <div>
      akash
    </div>
  )
}
